---
name: Feature request
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

### Titolo: Aggiungere la Funzionalità di Recupero Password

### Descrizione:
**Descrizione della Funzionalità Richiesta**:
Vorrei che venisse aggiunta una funzionalità di recupero password nella schermata di login.

**Motivo per cui è Necessaria**:
Gli utenti dimenticano spesso le loro password e al momento non c'è un modo per recuperarle.

**Suggerimenti su Come Implementarla**:
Aggiungere un link "Hai dimenticato la password?" nella schermata di login che invii un'email con le istruzioni per il reset.
